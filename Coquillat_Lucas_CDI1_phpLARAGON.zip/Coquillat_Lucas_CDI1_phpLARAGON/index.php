<?php
function calculerMoyenne($nombre1, $nombre2, $nombre3) {
    return ($nombre1 + $nombre2 + $nombre3) / 3;
}

function afficherResultat($nom, $moyenne) {
    $resultat = $moyenne >= 10 ? "suffisante" : "insuffisante";
    echo "La moyenne de $nom est $moyenne : $resultat";
}

// Vérification si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre1 = floatval($_POST['nombre1']);
    $nombre2 = floatval($_POST['nombre2']);
    $nombre3 = floatval($_POST['nombre3']);
    $nom = $_POST['nom'];
    
    $moyenne = calculerMoyenne($nombre1, $nombre2, $nombre3);
    afficherResultat($nom, $moyenne);
} else {
    // Formulaire HTML
    ?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Calcul de la moyenne</title>
    <link rel="stylesheet" href="main.css">
    </head>
    <body>
    <form method="POST">
        <label>Nom: <input type="text" name="nom" required style="margin-left: 35px;"></label><br>
        <label>Nombre 1: <input type="number" step="0.01" name="nombre1" required></label><br>
        <label>Nombre 2: <input type="number" step="0.01" name="nombre2" required></label><br>
        <label>Nombre 3: <input type="number" step="0.01" name="nombre3" required></label><br>
        <input id="submit-button" type="submit" value="Calculer la moyenne">
    </form>
    </body>
</html>
    <?php
}

