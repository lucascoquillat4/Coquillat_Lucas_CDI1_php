<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

//Créer un client http
$client = new Client();
$response = $client->request('GET', 'https://api.harvardartmuseums.org/image?apikey=f8d91983-f617-4667-9946-f1d6c3aba244');

$data = json_decode($response->getBody(), true);

//Afficher les données
echo "<pre>";
var_dump($data); //Afficher toutes les données de l'API
echo "</pre>";

var_dump($response); //Afficher toutes les données de l'API
?>